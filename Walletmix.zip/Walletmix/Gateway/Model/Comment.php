<?php



class Walletmix_Gateway_Model_Comment

{

public function getCommentText(){ 

        

		//$home_url = Mage::helper('core/url')->getHomeUrl();
		$home_url=substr(Mage::getBaseUrl(),0,-10);

		return '<span style="background-color:#454545;color:#fff; padding:5px 10px;">'.$home_url.'</span><br/>Copy this url during merchant registration.';

} 



}