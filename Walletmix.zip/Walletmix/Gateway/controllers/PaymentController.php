<?php
/*
Walletmix Gateway Payment Controller
By: Walletmix
www.walletmix.com
*/

class Walletmix_Gateway_PaymentController extends Mage_Core_Controller_Front_Action {
	// The redirect action is triggered when someone places an order
	public function redirectAction() {
		$this->loadLayout();
        $block = $this->getLayout()->createBlock('Mage_Core_Block_Template','gateway',array('template' => 'gateway/redirect.phtml'));
		$this->getLayout()->getBlock('content')->append($block);
        $this->renderLayout();
	}
	
	// The response action is triggered when your gateway sends back a response after processing the customer's payment
	public function responseAction() {
		if($this->getRequest()->isPost()) {
			
			$validated = $_POST['pay_status'];
			$orderId = $_POST['mer_txnid']; 
			$order = Mage::getModel('sales/order');
			$order->loadByIncrementId($orderId);
			
			if($validated=="success") {
				// Payment was successful, so update the order's state, send order email and move to the success page
				
				$order->setState(Mage_Sales_Model_Order::STATE_PROCESSING, true, $this->getMessage());
				
				$order->sendNewOrderEmail();
				$order->setEmailSent(true);
				
				$order->save();
			
				Mage::getSingleton('checkout/session')->unsQuoteId();
				
				Mage_Core_Controller_Varien_Action::_redirect('checkout/onepage/success', array('_secure'=>true));
			}
			else {
				// There is a problem in the response we got
				$this->cancelAction();
				Mage_Core_Controller_Varien_Action::_redirect('checkout/onepage/failure', array('_secure'=>true));
			}
		}
		else
			Mage_Core_Controller_Varien_Action::_redirect('');
	}
	
	// The cancel action is triggered when an order is to be cancelled
	public function cancelAction() {
        if (Mage::getSingleton('checkout/session')->getLastRealOrderId()) {
            $order = Mage::getModel('sales/order')->loadByIncrementId(Mage::getSingleton('checkout/session')->getLastRealOrderId());
            if($order->getId()) {
				// Flag the order as 'cancelled' and save it
				$order->cancel()->setState(Mage_Sales_Model_Order::STATE_CANCELED, true, $this->getMessage())->save();
			}
        }
	}
	
	private function getMessage(){
	$message='';
	$messageArray=array(
		'Payment status'=>$_POST['pay_status'],
		'Walletmix Transaction ID'=>$_POST['walletmix_txnid'],
		'Your Oder id'=>$_POST['mer_txnid'],
		'Currency merchant'=>$_POST['currency_merchant'],
		'Currency walletmix'=>$_POST['currency'],
		'Currency conversion rate'=>$_POST['convertion_rate'],
		'Receiveable amount after Walletmix service'=>$_POST['store_amount'],
		'Payment date'=>$_POST['pay_time'],
		'Bank Transaction ID'=>$_POST['bank_txn'],
		'Card number'=>$_POST['card_number'],
		'Card name'=>$_POST['card_name'],
		'Card type'=>$_POST['card_type'],
		'Customer IP addresss'=>$_POST['ip_address'],
		'Currency charged in BDT'=>$_POST['walletmix_service_charge_bdt'],
		'Reason'=>$_POST['reason']
	);
	
	foreach($messageArray as $k=>$v){
		$message .= $k."=".$v."\n";
	}
	
	$message = nl2br(strip_tags($message));
		return $message;
	}
	
}